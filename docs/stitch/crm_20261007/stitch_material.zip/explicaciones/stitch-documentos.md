He generado la pantalla de **«Gestión > Documentos > Revisar factura»** para CUE Digital en resolución de escritorio (1440x1100), integrada de forma estricta con el sistema de diseño AgroCUE Enterprise y la arquitectura v0 de navegación:

### Puntos clave del diseño:
1. **Banner y navegación institucional**: Mantiene el aviso reglamentario `DATOS FICTICIOS DE DISEÑO`, la barra de contexto de 64 px con la explotación activa (`Finca Las Dehesas y Riberas`), campaña 2024/2025, buscador y botón de `+ Nuevo apunte`. El sidebar de 240 px mantiene activa la sección `Gestión > Documentos`.
2. **Flujo de trabajo paso a paso**: Barra superior con la secuencia `1. Original → 2. Revisar datos (Paso actual) → 3. Vincular a compras → 4. Confirmar en libro de cuentas`.
3. **Alerta de duplicado**: Banner preventivo en color ámbar que advierte de una transacción previa idéntica de 1.210,00 € emitida el 15/03/2026 por `ProveedorEjemplo S.L.`, con acceso directo a cotejarla.
4. **Columna izquierda (Documento original simulado)**: Reproducción de la factura física en papel con marca de agua `DOCUMENTO DE EJEMPLO — FACTURA FICTICIA`, desglose de base (1.000,00 €), IVA 21% (210,00 €) y total (1.210,00 €), controles de visor de página y aviso explícito de *Pendiente de pago (no sirve como justificante de abono realizado)*.
5. **Columna derecha (Campos extraídos y trazabilidad OCR)**:
   - Estado de extracción marcado honestamente como *Propuesta automática pendiente de revisión humana (no validada)* con nivel de certeza del motor.
   - Campos de formulario editables con altura mínima táctil de 44 px e indicación de procedencia.
   - Datos no resueltos indicados en ámbar como `No comprobado` (ej. lote/registro oficial fitosanitario) sin asumir falsas conformidades.
   - Vinculación explícita con `Gestión > Cuentas` y `Almacén`, detallando en lenguaje claro que la entrada física de stock no se imputa automáticamente hasta la comprobación del albarán de recepción en campo.
6. **Barra fija inferior de acciones**: Controles con `Guardar para después`, `Rechazar propuesta OCR` y botón primario en verde bosque `#1f4a2c` para `Confirmar datos y registrar factura`.