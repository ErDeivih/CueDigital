He diseñado la experiencia móvil de campo para **CUE Digital** (`390×844 px`), concebida específicamente para operarios y agricultores en cabina de tractor o a pie de parcela bajo luz solar directa:

### Decisiones de diseño y adaptaciones clave:
1. **Modo Campo táctil (Targets ≥ 64px)**:
   - Todos los pasos del asistente (`1. QUÉ`, `2. DÓNDE`, `3. CANT.`, `4. REVISAR`) y los botones de acción principal cuentan con un tamaño táctil mínimo de 64 px con contornos nítidos y alto contraste para uso con guantes o vibración.
   - Tipografía principal de 18 px (`text-body-lg`) con etiquetas siempre visibles, sin campos colapsados ni texto diminuto.
   - Eliminadas sombras difuminadas, degradados y fotografías superfluas; estética plana y sólida fundamentada en `#1f4a2c` y fondos contrastados.

2. **Gestión de conectividad y modo offline**:
   - Indicador persistente superior: **«Sin conexión (hace 42 min)»** con contador de **3 apuntes en cola local**.
   - Distinción explícita de seguridad jurídica: aclaración visual entre **almacenamiento local en el dispositivo** y la sincronización pendiente con SIEX/REGEPA al recuperar cobertura.

3. **Flujo de revisión de labor ('Rodillo' en 'El camino largo')**:
   - Datos agronómicos verificados: labor de **Pase de rodillo compactador / desterronador**, fecha **7 de octubre de 2026 (09:30 h)**, superficie **4,44 ha** (Recinto SIGPAC `45-091-0-0-12-1`).
   - Mención reglamentaria: **«Cultivo Trigo se conserva»** sin afección sobre la declaración de la PAC.
   - Asignación real de tractor/apero y operario responsable acreditado.

4. **Zona de acción ergonómica**:
   - Botón primario prominente de 64 px: **«APUNTAR RODILLO EN ESTA TIERRA»**, acompañado de botón secundario **«Volver a modificar datos»**, con padding inferior de seguridad para evitar solapamientos con la barra de navegación de 5 accesos (Campo, Cuaderno, Registrar, Normativa, Ajustes).