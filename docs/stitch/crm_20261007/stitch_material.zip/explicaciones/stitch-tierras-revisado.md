He adaptado la pantalla **Tierras y mapa** convirtiéndola en un CRM ágil y funcional para la gestión directa de la explotación a 1440px:

### Cambios aplicados:
1. **Desburocratización total:**
   - Se eliminaron por completo todas las referencias a organismos e integraciones estatales (SIEX, REGEPA, listas PAC, conformidad administrativa, sincronizaciones obligatorias y bloqueos de fertilización).
   - En la cabecera superior se conservó únicamente el aviso solicitado: `DATOS FICTICIOS DE DISEÑO`.
   - Se reemplazaron las acciones burocráticas por accesos sencillos y claros (`Normativa aplicable`, `Soporte`).

2. **Cabecera y navegación:**
   - Selectores alineados sin solapamientos ni desbordes: `Finca Ejemplo`, `Campaña 2026`, buscador (`Buscar en el cuaderno...`) y botón primario `+ Nuevo apunte`.
   - Título de la página: `Tierras y mapa` con la descripción `Consulta tus tierras y lo último que has hecho.`
   - Acciones principales: `Añadir tierra` y `Exportar listado`.

3. **4 Tarjetas de resumen limpias:**
   - `64 Tierras`
   - `10 Falta decir el cultivo`
   - `3 Sin forma`
   - `Última revisión: No comprobado`

4. **Tabla de inventario a ancho completo:**
   - Ya no está comprimida lateralmente por el mapa.
   - Columnas: `Nombre` (mínimo 260px), `Hectáreas`, `Cultivo`, `Última labor`, `Pendientes` y `Abrir` (con botón visible `Ver`).
   - Filas añadidas con nombres reales de parcelas: `El camino largo junto a la carretera`, `La ladera` y `El prado`, con referencias secundarias legibles a 16px base, badges claros de cultivo (`Falta decirlo`, `Cebada`) y valores (`No comprobado`, labores recientes).
   - Pie con indicador `10 de 64 tierras` y paginación.

5. **Mapa reubicado debajo de la tabla:**
   - Panel amplio debajo de los datos tabulares con la etiqueta requerida `Esquema ficticio, sin ubicación real` y el aviso `3 tierras sin forma — ver lista`.
   - Representación vectorial con polígonos irregulares orgánicos y controles de visor (+ / - / pantalla completa).