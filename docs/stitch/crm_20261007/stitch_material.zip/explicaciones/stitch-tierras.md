He diseñado la pantalla completa **«Tierras y mapa - CUE Digital»** (escritorio 1440×1000) adaptada estrictamente a la normativa de cuaderno digital y a la especificación de diseño:

### Decisiones de diseño e implementación:
1. **Identidad y Shell v0**:
   - Barra lateral izquierda blanca de 240 px con la navegación estructurada: *Inicio*, *Campo* (con *Tierras y mapa* activo y resaltado en verde bosque `#1f4a2c`, *Trabajos*, *Cultivos y PAC*, *Almacén*), *Gestión* (*Documentos*, *Cuentas*, *Personas*, *Maquinaria*), *Cuaderno*, *Normativa* y *Ajustes*, junto al pie con *Validar CUE* y datos de explotación.
   - Cabecera de contexto de 64 px con selector de finca activa (*Finca Las Dehesas y Riberas*), campaña activa 2024/2025, buscador de cuaderno y botón primario de 44 px `+ Nuevo apunte`.
   - Banner superior informativo reglamentario: `DATOS FICTICIOS DE DISEÑO — Entorno de demostración CUE Digital`.

2. **Panel de control y resumen de tierras**:
   - Título principal **64 tierras** con métricas clave: **10 sin cultivo dicho** (aviso prioritario), **3 sin forma** (sin delimitación vectorial), **51 listas PAC / SIEX** y **Superficie total de 342,80 ha**.
   - Barra de filtros con controles de 44 px, chip activo removible `✕ Falta decir cultivo` y acción directa `Ver todas (limpiar filtro)`.

3. **Tabla de datos y legibilidad**:
   - Tipografía Segoe UI con cuerpo mínimo de 16 px y etiquetas claras, sin sombras innecesarias ni degradados.
   - Columnas para nombre de paraje con ajuste de línea largo, referencia catastral/SIGPAC, superficie, cultivo asignado diferenciando rigurosamente `Falta decir cultivo` / `No comprobado` frente a `Barbecho tradicional`, última labor y validaciones pendientes.
   - Fila activa seleccionada (`Paraje Arroyo de los Molinos`) conectada con el visor lateral.

4. **Panel cartográfico ficticio y detalle contextual**:
   - Visor vectorial ilustrativo marcado de forma explícita como *«Esquema vectorial ficticio — no representa ubicación real SIGPAC»*, con el aviso destacado de las 3 tierras sin geometría cartográfica.
   - Detalle de la parcela seleccionada con acciones de resolución rápida y disposición fluida que se reordena bajo la tabla en anchos de 1024 px.