'use client'

import { useMemo, useState } from 'react'
import {
  AlertCircle,
  Archive,
  ArrowLeft,
  BadgeEuro,
  Bell,
  BookOpen,
  CalendarDays,
  ChevronDown,
  ClipboardList,
  FileText,
  Filter,
  Grid3X3,
  LayoutDashboard,
  Map,
  Menu,
  MoreHorizontal,
  Plus,
  Search,
  Settings,
  Tractor,
  UserRound,
  Users,
  Wheat,
  X,
} from 'lucide-react'

type PlotStatus = 'Cultivo' | 'Sin cultivo' | 'No comprobado'
type Plot = { id: string; name: string; crop: string; area: string; status: PlotStatus; geometry: string; inspection: string }

const plots: Plot[] = Array.from({ length: 64 }, (_, index) => {
  const id = String(index + 1).padStart(2, '0')
  const missingCrop = [8, 19, 42, 47, 58, 61, 63, 27, 34, 53].includes(index + 1)
  const missingGeometry = [16, 39, 55].includes(index + 1)
  const overdue = [12, 31, 49].includes(index + 1)
  return {
    id,
    name: `Parcela ${id}`,
    crop: missingCrop ? 'No comprobado' : index % 3 === 0 ? 'Trigo blando' : index % 3 === 1 ? 'Cebada' : 'Girasol',
    area: `${(2.4 + (index % 7) * 0.8).toFixed(1)} ha`,
    status: missingCrop ? 'Sin cultivo' : 'Cultivo',
    geometry: missingGeometry ? 'Falta geometría' : 'Registrada',
    inspection: overdue ? 'Revisión vencida' : index % 4 === 0 ? 'Pendiente' : 'Al día',
  }
})

const navGroups = [
  { label: 'Campo', items: [['Tierras', Map], ['Trabajos', ClipboardList], ['Cultivos y PAC', Wheat], ['Almacén', Archive]] },
  { label: 'Gestión', items: [['Documentos', FileText], ['Cuentas', BadgeEuro], ['Personas', Users], ['Maquinaria', Tractor]] },
]

function StatusDot({ tone }: { tone: 'green' | 'amber' | 'gray' | 'red' }) {
  return <span aria-hidden="true" className={`status-dot status-dot--${tone}`} />
}

function AppSidebar({ active, onSelect, open, onClose }: { active: string; onSelect: (item: string) => void; open: boolean; onClose: () => void }) {
  return (
    <aside className={`sidebar ${open ? 'sidebar--open' : ''}`} aria-label="Navegación principal">
      <div className="brand-row">
        <div className="brand-mark">CUE</div>
        <div><div className="brand-name">CUE Digital</div><div className="brand-caption">CRM agrícola</div></div>
        <button className="icon-button sidebar-close" aria-label="Cerrar menú" onClick={onClose}><X /></button>
      </div>
      <div className="workspace-switcher"><div><span className="eyebrow">EXPLOTACIÓN</span><strong>Finca La Encina</strong></div><ChevronDown aria-hidden="true" /></div>
      <nav className="nav-groups">
        {navGroups.map((group) => <div key={group.label} className="nav-group"><div className="nav-label">{group.label}</div>{group.items.map(([label, Icon]) => <button key={label as string} className={`nav-item ${active === label ? 'nav-item--active' : ''}`} onClick={() => { onSelect(label as string); onClose() }}><Icon aria-hidden="true" /><span>{label as string}</span>{label === 'Tierras' && <span className="nav-count">64</span>}</button>)}</div>)}
        <div className="nav-group nav-group--bottom"><button className={`nav-item ${active === 'Cuaderno' ? 'nav-item--active' : ''}`} onClick={() => onSelect('Cuaderno')}><BookOpen aria-hidden="true" /><span>Cuaderno</span></button><button className="nav-item" onClick={() => onSelect('Normativa')}><FileText aria-hidden="true" /><span>Normativa</span></button><button className="nav-item" onClick={() => onSelect('Ajustes')}><Settings aria-hidden="true" /><span>Ajustes</span></button></div>
      </nav>
      <div className="sidebar-footer"><div className="avatar">MG</div><div className="user-meta"><strong>María García</strong><span>Administradora</span></div><MoreHorizontal aria-hidden="true" /></div>
    </aside>
  )
}

function Header({ onMenu, onNew }: { onMenu: () => void; onNew: () => void }) {
  return <header className="context-header"><button className="icon-button mobile-menu" aria-label="Abrir menú" onClick={onMenu}><Menu /></button><div className="breadcrumb"><span>Campo</span><span>/</span><strong>Tierras</strong></div><div className="header-actions"><button className="year-select">Campaña 2025/26 <ChevronDown /></button><label className="search-field"><Search aria-hidden="true" /><input aria-label="Buscar" placeholder="Buscar" /></label><button className="icon-button notifications" aria-label="Notificaciones"><Bell /><span /></button><button className="button button--primary" onClick={onNew}><Plus aria-hidden="true" /> Nuevo registro</button></div></header>
}

function SummaryCard({ label, value, detail, tone = 'green' }: { label: string; value: string; detail: string; tone?: 'green' | 'amber' | 'red' }) {
  return <article className="summary-card"><div className="summary-top"><span className="eyebrow">{label}</span><StatusDot tone={tone} /></div><strong>{value}</strong><span className="summary-detail">{detail}</span></article>
}

function PlotTable({ selected, onSelect }: { selected: Plot | null; onSelect: (plot: Plot) => void }) {
  const [filter, setFilter] = useState('Todas')
  const filtered = useMemo(() => plots.filter((plot) => filter === 'Todas' || (filter === 'Sin cultivo' ? plot.status === 'Sin cultivo' : plot.inspection === 'Revisión vencida')), [filter])
  return <section className="panel table-panel"><div className="panel-heading"><div><span className="eyebrow">REGISTRO DE TIERRAS</span><h2>Parcelas <span className="heading-count">64</span></h2></div><div className="view-toggle"><button className="view-toggle__active" aria-label="Vista tabla"><Grid3X3 /></button><button aria-label="Vista mapa"><Map /></button></div></div><div className="filter-row"><div className="filter-chips" role="group" aria-label="Filtrar parcelas">{['Todas', 'Sin cultivo', 'Revisión vencida'].map((item) => <button key={item} className={`filter-chip ${filter === item ? 'filter-chip--active' : ''}`} onClick={() => setFilter(item)}>{item}{item === 'Sin cultivo' && <span>10</span>}{item === 'Revisión vencida' && <span>3</span>}</button>)}</div><button className="button button--quiet"><Filter aria-hidden="true" /> Más filtros</button></div><div className="table-wrap"><table><thead><tr><th>Parcela</th><th>Cultivo</th><th>Superficie</th><th>Geometría</th><th>Inspección</th><th><span className="sr-only">Acciones</span></th></tr></thead><tbody>{filtered.slice(0, 8).map((plot) => <tr key={plot.id} className={selected?.id === plot.id ? 'row-selected' : ''} onClick={() => onSelect(plot)}><td><strong>{plot.name}</strong><span className="table-sub">Ref. {plot.id}-FLE</span></td><td><span className="crop-cell"><StatusDot tone={plot.status === 'Cultivo' ? 'green' : 'gray'} />{plot.crop}</span></td><td>{plot.area}</td><td><span className={plot.geometry === 'Registrada' ? 'text-muted' : 'warning-text'}>{plot.geometry}</span></td><td><span className={`inspection inspection--${plot.inspection === 'Al día' ? 'ok' : plot.inspection === 'Pendiente' ? 'pending' : 'overdue'}`}>{plot.inspection}</span></td><td><button className="row-more" aria-label={`Más acciones para ${plot.name}`}><MoreHorizontal /></button></td></tr>)}</tbody></table></div><div className="table-footer"><span>Mostrando {filtered.length > 8 ? '8' : filtered.length} de {filtered.length} parcelas</span><button className="text-button">Ver todas <ArrowLeft aria-hidden="true" /></button></div></section>
}

function FieldMap({ onSelect }: { onSelect: (plot: Plot) => void }) {
  return <section className="panel map-panel"><div className="panel-heading"><div><span className="eyebrow">DISTRIBUCIÓN</span><h2>Mapa de parcelas</h2></div><button className="icon-button" aria-label="Abrir mapa"><MoreHorizontal /></button></div><div className="field-map"><div className="map-label map-label--top">N</div><div className="plot-grid">{plots.map((plot, index) => <button key={plot.id} title={`${plot.name}, ${plot.crop}`} aria-label={`${plot.name}, ${plot.crop}`} onClick={() => onSelect(plot)} className={`map-plot map-plot--${plot.status === 'Cultivo' ? index % 4 === 0 ? 'olive' : 'green' : 'empty'} ${plot.geometry !== 'Registrada' ? 'map-plot--missing' : ''}`}><span>{plot.id}</span></button>)}</div><div className="map-legend"><span><i className="legend-swatch legend-swatch--green" />Con cultivo</span><span><i className="legend-swatch legend-swatch--olive" />Alternativo</span><span><i className="legend-swatch legend-swatch--empty" />Sin cultivo</span></div></div></section>
}

function DetailPanel({ plot, onClose }: { plot: Plot; onClose: () => void }) {
  return <aside className="detail-panel" aria-label="Detalle de parcela"><div className="detail-header"><div><span className="eyebrow">DETALLE DE PARCELA</span><h2>{plot.name}</h2><span className="detail-ref">Ref. {plot.id}-FLE · Finca La Encina</span></div><button className="icon-button" aria-label="Cerrar detalle" onClick={onClose}><X /></button></div><div className="detail-status"><StatusDot tone={plot.status === 'Cultivo' ? 'green' : 'gray'} /><strong>{plot.crop}</strong><span>{plot.area}</span></div><div className="detail-tabs"><button className="detail-tab detail-tab--active">Resumen</button><button className="detail-tab">Historial</button><button className="detail-tab">Costes</button></div><div className="detail-body"><div className="detail-section"><div className="section-title"><h3>Próxima actividad</h3><span className="inspection inspection--pending">Pendiente</span></div><div className="activity-card"><CalendarDays /><div><strong>Revisión de nascencia</strong><span>18 mayo 2026 · Sin asignar</span></div></div></div><div className="detail-section"><div className="section-title"><h3>Cultivo actual</h3><button className="text-button">Editar</button></div><dl className="detail-list"><div><dt>Campaña</dt><dd>2025/26</dd></div><div><dt>Variedad</dt><dd>{plot.crop === 'No comprobado' ? 'No comprobado' : 'Triticum aestivum'}</dd></div><div><dt>Riego</dt><dd>No comprobado</dd></div><div><dt>Geometría</dt><dd className={plot.geometry !== 'Registrada' ? 'warning-text' : ''}>{plot.geometry}</dd></div></dl></div><div className="detail-section"><div className="section-title"><h3>Últimos movimientos</h3><button className="text-button">Ver todo</button></div><ol className="timeline"><li><span className="timeline-marker" /><div><strong>Aplicación registrada</strong><span>Urea · 12 abril 2026</span></div></li><li><span className="timeline-marker timeline-marker--muted" /><div><strong>Trabajo de suelo</strong><span>Gradeo · 02 marzo 2026</span></div></li></ol></div></div><div className="detail-footer"><button className="button button--secondary"><Plus aria-hidden="true" /> Añadir movimiento</button></div></aside>
}

export default function Page() {
  const [active, setActive] = useState('Tierras')
  const [menuOpen, setMenuOpen] = useState(false)
  const [selected, setSelected] = useState<Plot | null>(null)
  const [showToast, setShowToast] = useState(false)
  const handleNew = () => { setShowToast(true); window.setTimeout(() => setShowToast(false), 2500) }
  return <div className="app-shell"><AppSidebar active={active} onSelect={setActive} open={menuOpen} onClose={() => setMenuOpen(false)} /><div className="app-main"><Header onMenu={() => setMenuOpen(true)} onNew={handleNew} /><main className="page-content"><div className="page-title-row"><div><span className="eyebrow">MARTES, 7 DE OCTUBRE DE 2026</span><h1>Buenos días, María</h1><p>Resumen de tu explotación para la campaña 2025/26.</p></div><div className="title-actions"><button className="button button--secondary"><CalendarDays aria-hidden="true" /> Ver calendario</button></div></div><section className="summary-grid"><SummaryCard label="Superficie gestionada" value="286,4 ha" detail="64 parcelas registradas" /><SummaryCard label="Cultivos activos" value="54" detail="10 parcelas sin cultivo" tone="amber" /><SummaryCard label="Trabajos pendientes" value="8" detail="2 requieren atención" tone="amber" /><SummaryCard label="Costes campaña" value="42.680 €" detail="Pago parcial registrado" tone="red" /></section><div className="content-grid"><div className="content-column"><PlotTable selected={selected} onSelect={setSelected} /><section className="panel attention-panel"><div className="panel-heading"><div><span className="eyebrow">PARA REVISAR</span><h2>Atención recomendada</h2></div><AlertCircle aria-hidden="true" /></div><div className="attention-list"><div><span className="attention-icon attention-icon--amber"><Map /></span><div><strong>3 parcelas sin geometría</strong><span>Completa el límite para mejorar el registro de superficie.</span></div><button className="text-button">Revisar</button></div><div><span className="attention-icon attention-icon--red"><CalendarDays /></span><div><strong>3 inspecciones vencidas</strong><span>Hay revisiones pendientes desde abril de 2026.</span></div><button className="text-button">Ver tareas</button></div></div></section></div><div className="content-column"><FieldMap onSelect={setSelected} /><section className="panel quick-panel"><div><span className="eyebrow">ACCESOS RÁPIDOS</span><h2>Registrar una actividad</h2></div><div className="quick-actions"><button><ClipboardList /><span>Trabajo de campo</span></button><button><BadgeEuro /><span>Coste o pago</span></button><button><FileText /><span>Documento</span></button></div></section></div></div></main></div>{selected && <DetailPanel plot={selected} onClose={() => setSelected(null)} />}{showToast && <div className="toast" role="status">Nuevo registro listo para completar</div>}</div>
}
